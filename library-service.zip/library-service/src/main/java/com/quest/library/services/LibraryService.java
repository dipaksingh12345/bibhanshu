package com.quest.library.services;

import java.util.List;

import com.quest.library.entity.Book;


public interface LibraryService {

	Book addbook(Book book);

	List<Book> getAllBooks();

	Book getBookById(Long bookId);	
	
	List<Book> searchBook();
	
	List<Book> searchBookByName(String subject);

	Book updateBook(Book book, long bookId);

	void deleteBook(long bookId);


}
