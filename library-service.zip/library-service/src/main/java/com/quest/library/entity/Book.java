package com.quest.library.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="book")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)


	@Column(name="book_id")
	private Long bookId;

	@Column(name="subject_name")
	private String subject;

	@Column(name="author_name")
	private String authorName;

	@Column(name="book_price")
	private float price;


	public Book() {
		super();
	}


	public Book(Long bookId, String subject, String authorName, float price) {
		super();
		this.bookId = bookId;
		this.subject = subject;
		this.authorName = authorName;
		this.price = price;
	}


	public Long getBookId() {
		return bookId;
	}


	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public String getAuthorName() {
		return authorName;
	}


	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", subject=" + subject + ", authorName=" + authorName + ", price=" + price
				+ "]";
	}


}
