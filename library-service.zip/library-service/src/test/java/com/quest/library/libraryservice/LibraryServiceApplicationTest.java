package com.quest.library.libraryservice;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.quest.library.entity.Book;
import com.quest.library.repository.LibraryRepository;

//here I am also checking my testcases with database
//I have to call the method one by one

@RunWith(SpringRunner.class)
@SpringBootTest
class LibraryServiceApplicationTest{

	@Autowired
	private LibraryRepository libraryRepository;

	@Test
	 public void saveBookTest() {
		Book book = new Book();
		book.setBookId(1L);
		book.setAuthorName("kanetkar");
		book.setSubject("C,C++");
		book.setPrice(500);
		libraryRepository.save(book);
		assertNotNull(libraryRepository.findById(1L).get());
	}

	@Test
	 public void allBookTest() {
		List<Book> list =	libraryRepository.findAll();
		assertThat(list).size().isGreaterThan(0);

	}

 @Test
	public void bookBySubjectTest() {

		Book book = libraryRepository.findById(1L).get();
		assertEquals("C,C++", book.getSubject());

	}
 
	@Test
	 public void bookUpdateTest(){

		Book b = libraryRepository.findById(1L).get();
		b.setSubject("Java");
		libraryRepository.save(b);
       assertNotEquals("C,C++", libraryRepository.findById(1L).get().getSubject());

	}

	@Test
	public void bookDeleteTest() {

		libraryRepository.deleteById(1L);
		assertThat(libraryRepository.existsById(1L)).isFalse();
	}





}
