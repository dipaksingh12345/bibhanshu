package com.quest.admin.sevices;

import com.quest.admin.entity.IssueBook;
import com.quest.admin.response.ResponseTemplate;

public interface AdminService {
	
	
	public ResponseTemplate getIssueBook(int issueBookId);

	public IssueBook saveIssueBook(IssueBook issueBook);

}
