package com.quest.admin.entity;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class IssueBook implements Serializable {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique=true, nullable=false)
	private int issueBookId;
	private LocalDate issueDate = LocalDate.now();
	private LocalDate returnDate = issueDate.plusDays(7);
	private int bookId;
	private Long stdId;

	public IssueBook() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IssueBook(int issueBookId, LocalDate issueDate, LocalDate returnDate, int bookId, Long stdId) {
		super();
		this.issueBookId = issueBookId;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.bookId = bookId;
		this.stdId = stdId;
	}

	public int getIssueBookId() {
		return issueBookId;
	}

	public void setIssueBookId(int issueBookId) {
		this.issueBookId = issueBookId;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public Long getStdId() {
		return stdId;
	}

	public void setStdId(Long stdId) {
		this.stdId = stdId;
	}

	@Override
	public String toString() {
		return "IssueBook [issueBookId=" + issueBookId + ", issueDate=" + issueDate + ", returnDate=" + returnDate
				+ ", bookId=" + bookId + ", stdId=" + stdId + "]";
	}


}
