package com.quest.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.quest.admin.entity.IssueBook;

@Repository
public interface AdminBookRepository extends JpaRepository<IssueBook, Integer> {

}
