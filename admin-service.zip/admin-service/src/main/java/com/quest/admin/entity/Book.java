package com.quest.admin.entity;

public class Book {
	private Long bookId;
    private String subject;
    private String authorName;
    private float price;


	public Book() {
		super();
	}


	public Book(Long bookId, String subject, String authorName, float price) {
		super();
		this.bookId = bookId;
		this.subject = subject;
		this.authorName = authorName;
		this.price = price;
	}


	public Long getBookId() {
		return bookId;
	}


	public void setBookId(Long bookId) {
		this.bookId = bookId;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public String getAuthorName() {
		return authorName;
	}


	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", subject=" + subject + ", authorName=" + authorName + ", price=" + price
				+ "]";
	}


	 



}
