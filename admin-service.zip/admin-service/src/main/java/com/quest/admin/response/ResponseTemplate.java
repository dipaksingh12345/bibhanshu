package com.quest.admin.response;

import com.quest.admin.entity.Book;
import com.quest.admin.entity.IssueBook;
import com.quest.admin.entity.Student;

public class ResponseTemplate {

	
	private Student student;
	private Book book;
	private IssueBook issueBook;

	public ResponseTemplate() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResponseTemplate(Student student, Book book, IssueBook issueBook) {
		super();
		this.student = student;
		this.book = book;
		this.issueBook = issueBook;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public IssueBook getIssueBook() {
		return issueBook;
	}

	public void setIssueBook(IssueBook issueBook) {
		this.issueBook = issueBook;
	}

	@Override
	public String toString() {
		return "ResponseTemplate [student=" + student + ", book=" + book + ", issueBook=" + issueBook + "]";
	}

}
