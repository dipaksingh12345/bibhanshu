package com.quest.book.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

// it internally uses @Getter @Setter @RequiredArgsConstructor @ToString @EqualsAndHashCode
@Entity
@Table(name = "book")
@Data

@NoArgsConstructor

public class Book {
	
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	
	@Column(name="book_id")
	private Long bookId;
    
    @Column(name="book_name")
	private String bookName;
	
	@Column(name="author_name")
	private String authorName;
	
	@Column(name="book_price")
	private float price;


	 
	
	
}
