package com.quest.book.services;

import java.util.List;

import com.quest.book.entity.Book;

public interface BookService{

	Book addbook(Book book);
	
	List<Book> getAllBooks();
	
	Book getBookById(Long bookId);	
	
	Book updateBook(Book book, long bookId);
	
	void deleteBook(long bookId);
	
//	Book getBookByName(String bookName);
	
}
