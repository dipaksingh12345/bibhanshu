package com.quest.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quest.book.entity.Book;
import com.quest.book.services.BookService; 
 

@RestController
@RequestMapping("/api/book")
public class BookController {

	
	@Autowired
	private BookService bookService;

	 
 
//	public BookController(BookService bookService) {
//		super();
//		this.bookService = bookService;
//	}

	//build create book rest api
	
	@PostMapping("/addbook")
	public ResponseEntity<Book>addbook(@RequestBody Book book){
		return new ResponseEntity<Book>(bookService.addbook(book), HttpStatus.CREATED);
		
		
	}
	
	//build get all books rest api
	@GetMapping("/getallbooks")
	
	public List<Book> getAllBooks(){
		return bookService.getAllBooks();
		
		
		
	}
	
	
	//build get bookbyid restapi
	@GetMapping("{id}")
	public ResponseEntity<Book> getBookById(@PathVariable("id")  long bookId){
		return new ResponseEntity<Book>(bookService.getBookById(bookId),HttpStatus.OK);
		
		
		
	}
	
	
	//build update book rest api
	@PutMapping("{id}")
	public ResponseEntity<Book> updateBook(@PathVariable("id") long bookId, @RequestBody Book book){
		return  new ResponseEntity<Book>(bookService.updateBook(book, bookId),HttpStatus.OK);
		
		
	}
	
	
	//build deletebook restapi
	
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteBook(@PathVariable("id") long bookId){
		
		bookService.deleteBook(bookId);
		return new ResponseEntity<String>("Book deleted successfully!!", HttpStatus.OK);
		
		
	}
	
	
	
	
	
}
