package com.quest.book.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quest.book.entity.Book;
import com.quest.book.exception.ResourceNotFoundException;
import com.quest.book.repository.BookRepository;
@Service
public class BookServiceImpl  implements BookService{

	
	@Autowired
	private BookRepository bookRepository;
	
	
//	public BookServiceImpl(BookRepository bookRepository) {
//		super();
//		this.bookRepository = bookRepository;
//	}

	@Override
	public Book addbook(Book book) {
		// TODO Auto-generated method stub
		return bookRepository.save(book);
	}

	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}

	@Override
	public Book getBookById(Long bookId) {
		// TODO Auto-generated method stub 
	Optional<Book> book = bookRepository.findById(bookId);
	// 1st way
//	if(book.isPresent()) {
//		
//		return book.get();
//	}else {
//		
//		throw new ResourceNotFoundException("Book", "bookId", bookId);
//	}
	
	//2nd way
	return bookRepository.findById(bookId).orElseThrow(()->new ResourceNotFoundException("Book", "BookID", bookId));
	
	
	}

	@Override
	public Book updateBook(Book book, long bookId) {
		// we need to check wheather book with given id is exist or not
		
		
		Book existingBook  = bookRepository.findById(bookId).orElseThrow(
				()->new ResourceNotFoundException("Book", "BookId", bookId));
		
		existingBook.setBookName(book.getBookName());
		existingBook.setAuthorName(book.getAuthorName());
		existingBook.setPrice(book.getPrice());
		//save existing book to db
		bookRepository.save(existingBook);
		
		return existingBook;
	}

	@Override
	public void deleteBook(long bookId) {
		// TODO Auto-generated method stub
		
		//check wheather a book exist in db or not
		bookRepository.findById(bookId).orElseThrow(
				()->new ResourceNotFoundException("Book", "BookId", bookId));
		
		bookRepository.deleteById(bookId);
	}

}
